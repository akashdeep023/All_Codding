# Amazon Clone

## A clone of the Amazon website for practicing web development skills.

## Technologies used :
   1. HTML
   2. CSS

## Author :
   Akash Deep
   Email: ad3500476@gmail.com

## Link :
   url : https://akashdeep023.github.io/Amazon-Clone/